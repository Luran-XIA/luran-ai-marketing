# Luran Xia · AI 营销工作台

魔搭国内创空间部署候选。保留12个营销功能、通用聊天、结果编辑、复制与Markdown下载。网页与后台同域运行，访客不配置API Key。

## 构建

使用Node.js 24，安装package.json中的依赖，运行 `npm run check` 与 `npm run build`。`dist/` 包含可部署网页及Node.js服务，已跟随源码提交；Docker运行时无需安装依赖。修改前端或服务端后需要重新构建。

通过平台网页上传时，选择 `dist/` 中的5个文件作为空间根目录：Dockerfile、server.mjs、index.html、config.json、README.md。该目录的Dockerfile直接复制这3个运行文件；源码根目录Dockerfile则复制整个dist，两者运行内容相同。

## 平台配置

- 选择Docker创空间，可用免费CPU资源需以账号实时返回为准。选择付费资源前需确认费用。
- 服务监听 `0.0.0.0:7860`。
- Secret：`DASHSCOPE_API_KEY`，只在平台服务端填写真实北京百炼密钥。
- 普通变量：`QWEN_BASE_URL`（已内置北京业务空间地址，可保持默认）。模型固定 `qwen-flash`。
- SQLite计数存储在 `/mnt/workspace/luran-marketing/quota.sqlite`。该目录依赖平台持久化；迁移或重命名空间时需另行保存，不能视为高可靠数据库。
- 全站每日100次、每分钟10次；按UTC日期计数，包括已发往模型但失败的调用。超额请求不会调用模型。重启后应保留计数。

## 接口

`GET /` 提供网页，`GET /config.json` 只包含同域配置及模型名，`GET /healthz` 提供服务状态。

`POST /api/generate` 接受现有任务请求格式；服务端校验输入、选取内置提示词后请求Qwen，前端不接收密钥。API不提供跨域CORS，Origin检查只限制浏览器来源，不等同于身份认证；公开额度是全站共享上限。

## 验收与当前状态

2026-10-10：类型检查及生产构建通过。本地模拟模型的接口检查通过：网页与同域配置、私有文件不对外提供、输入与Origin校验、Brief及聊天请求/返回格式、并行请求限额、进程重启后计数持久化。云端Docker镜像构建及真实Qwen调用已通过。

已创建公开空间 https://modelscope.cn/studios/LURANXIA/luran-ai-marketing ，上传5个运行文件，选择Docker / 免费CPU 2核8G / 7860，保存DASHSCOPE_API_KEY为Secret并启动部署。代码提交0a75f64d18a7ac7daff1caf3f0f3d9be3928d5ec。云端运行中；未登录窗口真实生成营销Brief、案例分析以及两轮聊天上下文均通过。不能用本机有代理的成功结果替代大陆直连验收。

源码项目：https://github.com/Luran-XIA/luran-ai-marketing
