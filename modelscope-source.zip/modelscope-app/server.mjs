import {createServer} from 'node:http';
import {readFile,mkdir} from 'node:fs/promises';
import {join} from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import {tasks,platforms,tones,buildUserPrompt,systemPrompt,chatSystem} from './frontend/marketing.ts';

const MODEL='qwen-flash';
const BASE=process.env.QWEN_BASE_URL||'https://llm-hz4ayz3dcgud2fn2.cn-beijing.maas.aliyuncs.com/compatible-mode/v1';
const DAY_LIMIT=100,MINUTE_LIMIT=10;
const LIMITS={product:2500,audience:400,goal:400,platform:30,tone:30,content:6000};
const assets=new URL('./',import.meta.url);
class InputError extends Error {}

function messagesFor(data){
 if(!data||typeof data!=='object'||!Object.hasOwn(tasks,data.task))throw new InputError('请选择有效的功能。');
 if(data.task==='chat'){
  const ms=data.messages;
  if(!Array.isArray(ms)||ms.length<1||ms.length>9||ms.length%2!==1)throw new InputError('对话格式无效，请清空对话后重试。');
  let size=0;
  const clean=ms.map((m,i)=>{
   if(!m||m.role!==(i%2?'assistant':'user')||typeof m.content!=='string'||!m.content.trim()||m.content.length>(i%2?16000:6000))throw new InputError('对话格式或长度无效。');
   size+=m.content.length;return {role:m.role,content:m.content};
  });
  if(size>20000)throw new InputError('对话过长，请开始新对话。');
  return [{role:'system',content:chatSystem},...clean];
 }
 const brief={};
 for(const [key,limit] of Object.entries(LIMITS)){
  const value=data.brief?.[key]??'';
  if(typeof value!=='string'||value.length>limit)throw new InputError('资料过长或格式无效。');
  brief[key]=value.trim();
 }
 if(!platforms.includes(brief.platform)||!tones.includes(brief.tone))throw new InputError('请选择支持的渠道与风格。');
 if(data.task!=='case'&&!brief.product)throw new InputError('请先填写产品定位和功能。');
 if(tasks[data.task].required&&!brief.content)throw new InputError('请先填写待分析的资料。');
 return [{role:'system',content:systemPrompt},{role:'user',content:buildUserPrompt(data.task,brief)}];
}

async function readBody(req){
 let total=0;const chunks=[];
 for await(const chunk of req){
  total+=chunk.length;if(total>65536)throw new InputError('资料过长，请缩短后重试。');
  chunks.push(chunk);
 }
 try{return JSON.parse(Buffer.concat(chunks).toString('utf8'));}
 catch{throw new InputError('请求格式无效。');}
}

const dataDir=process.env.DATA_DIR||'/mnt/workspace/luran-marketing';
await mkdir(dataDir,{recursive:true});
const db=new DatabaseSync(join(dataDir,'quota.sqlite'));
db.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; CREATE TABLE IF NOT EXISTS request_quota (bucket TEXT PRIMARY KEY, count INTEGER NOT NULL);');
const getCount=db.prepare('SELECT count FROM request_quota WHERE bucket=?');
const increment=db.prepare('INSERT INTO request_quota(bucket,count) VALUES (?,1) ON CONFLICT(bucket) DO UPDATE SET count=count+1');
const cleanup=db.prepare('DELETE FROM request_quota WHERE bucket < ?');
function consumeQuota(){
 const stamp=new Date().toISOString();
 const buckets=[['day:'+stamp.slice(0,10),DAY_LIMIT],['minute:'+stamp.slice(0,16),MINUTE_LIMIT]];
 db.exec('BEGIN IMMEDIATE');
 try{
  if(buckets.some(([key,max])=>(getCount.get(key)?.count||0)>=max)){db.exec('ROLLBACK');return false;}
  for(const [key] of buckets)increment.run(key);
  const old=new Date(Date.now()-2*86400000).toISOString().slice(0,10);
  cleanup.run('day:'+old);
  db.prepare("DELETE FROM request_quota WHERE bucket LIKE 'minute:%' AND bucket < ?").run('minute:'+old);
  db.exec('COMMIT');return true;
 }catch(error){db.exec('ROLLBACK');throw error;}
}

function reply(res,body,status=200){
 res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
 res.end(JSON.stringify(body));
}
function sameOrigin(req){
 try{
  const origin=new URL(req.headers.origin);
  const host=(req.headers['x-forwarded-host']||req.headers.host||'').split(',')[0].trim();
  return ['https:','http:'].includes(origin.protocol)&&origin.host===host;
 }catch{return false;}
}

const server=createServer(async(req,res)=>{
 try{
  const path=new URL(req.url,'http://localhost').pathname;
  if(req.method==='GET'&&path==='/healthz')return reply(res,{status:'ok'});
  if((req.method==='GET'||req.method==='HEAD')&&['/','/index.html','/config.json'].includes(path)){
   const name=path==='/config.json'?'config.json':'index.html';
   const file=await readFile(new URL(name,assets));
   res.writeHead(200,{'Content-Type':name.endsWith('.json')?'application/json; charset=utf-8':'text/html; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
   res.end(req.method==='HEAD'?undefined:file);return;
  }
  if(path!=='/api/generate')return reply(res,{error:'页面不存在。'},404);
  if(req.method!=='POST')return reply(res,{error:'请求方式不支持。'},405);
  if(!sameOrigin(req))return reply(res,{error:'请通过 Luran 营销工作台使用。'},403);
  if(!req.headers['content-type']?.startsWith('application/json'))return reply(res,{error:'请求格式无效。'},415);
  const messages=messagesFor(await readBody(req));
  if(!process.env.DASHSCOPE_API_KEY)return reply(res,{error:'AI服务配置尚未完成，请联系站长。'},503);
  const base=new URL(BASE);
  if(base.protocol!=='https:'||!base.hostname.endsWith('.aliyuncs.com')||base.username||base.password||base.search||base.hash)throw Error('invalid upstream');
  if(!consumeQuota())return reply(res,{error:'共享体验额度或调用频率已达上限，请稍后再试（全站每天100次、每分钟10次）。'},429);
  const response=await fetch(base.href.replace(/\/$/,'')+'/chat/completions',{
   method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+process.env.DASHSCOPE_API_KEY},
   body:JSON.stringify({model:MODEL,messages,enable_thinking:false,max_tokens:2600,temperature:0.2,stream:false}),
   signal:AbortSignal.timeout(55000)
  });
  if(!response.ok){
   await response.body?.cancel();
   return reply(res,{error:response.status===429?'模型额度或频率受限，请稍后再试。':'Qwen服务暂时不可用，请稍后重试或联系站长。'},response.status===429?429:502);
  }
  const data=await response.json();const content=data.choices?.[0]?.message?.content;
  if(typeof content!=='string'||!content.trim())return reply(res,{error:'模型未返回文本，请稍后再试。'},502);
  reply(res,{content,model:data.model||MODEL,inputTokens:data.usage?.prompt_tokens,outputTokens:data.usage?.completion_tokens,finishReason:data.choices?.[0]?.finish_reason});
 }catch(error){
  if(res.destroyed||res.writableEnded)return;
  reply(res,{error:error instanceof InputError?error.message:'AI服务暂时不可用，请稍后重试。'},error instanceof InputError?400:503);
 }
});
server.requestTimeout=70000;
server.listen(Number(process.env.PORT||7860),process.env.BIND_HOST||'0.0.0.0',()=>console.log('Luran marketing application is ready.'));
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>server.close(()=>{db.close();process.exit(0);}));
